using Godot;
using Microsoft.Win32.SafeHandles;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Security.Cryptography;

public partial class DiceSpawner : Node3D, Waitable
{
	public enum DieType
	{
		TETRAHEDRON = 0,
		CONE,
		FRUSTUM,
		BICONE,
		CUBE
	}
	public struct DieInfo
	{
		public RigidBody3D die;
		public MeshInstance3D visualDie;
		public DieType type;
		public float measure;
		public int[] ticks;
	}

	[Export] PackedScene diceScene;
	private Node3D[] dice;
	Random rand = new Random();
	private List<DieInfo> diceInst = new List<DieInfo>();
	private Dictionary<float, int>[] dieResults = new Dictionary<float, int>[6];
	private int currDice = 0;
	private static readonly int startAmt = 100;
	private static readonly int interval = 1;

	// Called when the node enters the scene tree for the first time.
	public override void _Ready()
	{
		Node3D diceSceneInstance = (Node3D)diceScene.Instantiate();
		dice = new Node3D[diceSceneInstance.GetChildCount()];
		for(int i = 0; i < diceSceneInstance.GetChildCount(); ++i)
		{
			dice[i] = (Node3D)diceSceneInstance.GetChild(i);
		}
		for (int i = 0; i < 6; ++i)
		{
			dieResults[i] = new Dictionary<float, int>();
			for (int k = 0; k < 5; ++k)
			{
				for (int j = 0; j < 20; ++j)
				{
					dieResults[i].Add(((j + 1) / 10f) + (k * 5), 0);
				}
				dieResults[i].Add(2.5f + (k * 5), 0);
				dieResults[i].Add(3.0f + (k * 5), 0);
				dieResults[i].Add(3.5f + (k * 5), 0);
				dieResults[i].Add(4.0f + (k * 5), 0);
				dieResults[i].Add(5.0f + (k * 5), 0);
			}
		}
		Tween.WaitToExecute(this, Waitable.WaitEvent.START_SPAWN, .1f);
	}
	
	// Called every frame. 'delta' is the elapsed time since the previous frame.
	public override void _PhysicsProcess(double delta)
	{
		float bounds = 4f;
		foreach (DieInfo dieInfo in diceInst)
		{
			RigidBody3D die = dieInfo.die;
			die.Position = new Vector3(
				Mathf.Clamp(die.Position.X, -bounds, bounds),
				Mathf.Clamp(die.Position.Y, 0, 15),
				Mathf.Clamp(die.Position.Z, -bounds, bounds));
			++dieInfo.ticks[1];
			if (((die.LinearVelocity.Length() < .1f && die.AngularVelocity.Length() < .1f)) || dieInfo.ticks[1] > 20000)
			{
				if (dieInfo.ticks[0] > 20 || dieInfo.ticks[1] > 20000)
				{
					//GD.Print(die.Rotation * 180.0f/Mathf.Pi);
					List<Vector3> rotatedMeshPoints = new List<Vector3>();
					//int k = 0;
					foreach (Vector3 v in dieInfo.visualDie.Mesh.GetFaces())
					{
						Vector3 rotatedPoint = new Vector3(v.X, v.Y, v.Z);
						rotatedPoint = new Vector3(
							(Mathf.Cos(die.Rotation.Z) * rotatedPoint.X) - (Mathf.Sin(die.Rotation.Z) * rotatedPoint.Y),
							(Mathf.Sin(die.Rotation.Z) * rotatedPoint.X) + (Mathf.Cos(die.Rotation.Z) * rotatedPoint.Y),
							rotatedPoint.Z);
						rotatedPoint = new Vector3(
							rotatedPoint.X,
							(Mathf.Sin(-die.Rotation.X) * rotatedPoint.Z) + (Mathf.Cos(-die.Rotation.X) * rotatedPoint.Y),
							(Mathf.Cos(-die.Rotation.X) * rotatedPoint.Z) - (Mathf.Sin(-die.Rotation.X) * rotatedPoint.Y));
						rotatedPoint = new Vector3(
							(Mathf.Cos(die.Rotation.Y) * rotatedPoint.Z) - (Mathf.Sin(die.Rotation.Y) * rotatedPoint.X),
							rotatedPoint.Y,
							(Mathf.Sin(die.Rotation.Y) * rotatedPoint.Z) + (Mathf.Cos(die.Rotation.Y) * rotatedPoint.X));
						rotatedMeshPoints.Add(rotatedPoint);
						//GD.Print(k++ + " " + v + " " + rotatedPoint);
					}
					List<float> faceHeights = new List<float>();
					int faceColor = 0;
					float sideHeight = 20;
					switch (dieInfo.type)
					{
						case DieType.TETRAHEDRON:
							for (int i = 0; i < 12; i += 3)
							{
								faceHeights.Add((
									rotatedMeshPoints[i].Y +
									rotatedMeshPoints[i + 1].Y +
									rotatedMeshPoints[i + 2].Y)
									/ 3.0f);
							}
							for (int i = 0; i < 4; ++i)
							{
								if (faceHeights[i] < sideHeight)
								{
									sideHeight = faceHeights[i];
									faceColor = i;
								}
							}
							break;
						case DieType.CONE:
							float hc = 0;
							for (int j = 0; j < 18; ++j)
							{
								hc += rotatedMeshPoints[j].Y;
							}
							faceHeights.Add(hc/ 18.0f);
							for (int i = 18; i < 42; i += 3)
							{
								faceHeights.Add((
									rotatedMeshPoints[i].Y +
									rotatedMeshPoints[i + 1].Y +
									rotatedMeshPoints[i + 2].Y)
									/ 3.0f);
							}
							for (int i = 0; i < 9; ++i)
							{
								if (faceHeights[i] < sideHeight)
								{
									sideHeight = faceHeights[i];
									faceColor = i <= 0 ? 0 : 1;
								}
							}
							break;
						case DieType.FRUSTUM:
							float hf = 0;
							for (int j = 0; j < 18; ++j)
							{
								hf += rotatedMeshPoints[j].Y;
							}
							faceHeights.Add(hf / 18.0f);
							hf = 0;
							for (int j = 18; j < 36; ++j)
							{
								hf += rotatedMeshPoints[j].Y;
							}
							faceHeights.Add(hf / 18.0f);
							for (int i = 36; i < 84; i += 6)
							{
								hf = 0;
								for (int j = i; j < i + 6; ++j)
								{
									hf += rotatedMeshPoints[j].Y;
								}
								faceHeights.Add(hf / 6.0f);
							}
							for (int i = 0; i < 10; ++i)
							{
								if (faceHeights[i] < sideHeight)
								{
									sideHeight = faceHeights[i];
									switch (i)
									{
										case 0:
											faceColor = 0;
											break;
										case 1:
											faceColor = 1;
											break;
										default:
											faceColor = 2;
											break;

									}
								}
							}
							break;
						case DieType.BICONE:
							float hb = 0;
							for (int i = 0; i < 48; i += 3)
							{
								hb = 0;
								for (int j = i; j < i + 3; ++j)
								{
									hb += rotatedMeshPoints[j].Y;
								}
								faceHeights.Add(hb / 3.0f);
							}
							for (int i = 0; i < 16; ++i)
							{
								if (faceHeights[i] < sideHeight)
								{
									sideHeight = faceHeights[i];
									faceColor = i < 8 ? 0 : 1;
								}
							}
							break;
						case DieType.CUBE:
							float hcu = 0;
							for (int i = 0; i < 36; i += 6)
							{
								hcu = 0;
								for (int j = i; j < i + 6; ++j)
								{
									hcu += rotatedMeshPoints[j].Y;
								}
								faceHeights.Add(hcu / 6.0f);
							}
							for (int i = 0; i < 6; ++i)
							{
								if (faceHeights[i] < sideHeight)
								{
									sideHeight = faceHeights[i];
									switch (i)
									{
										default:
											faceColor = i;
											break;
									}
								}
							}
							break;
						default: 
							break;
					}
					GD.Print(dieInfo.type + " " + dieInfo.measure + " " + faceColor);
					int prevDieRes = dieResults[faceColor].GetValueOrDefault(((int)dieInfo.type * 5.0f) + dieInfo.measure);
					dieResults[faceColor].Remove(((int)dieInfo.type * 5) + dieInfo.measure);
					dieResults[faceColor].Add(((int)dieInfo.type * 5) + dieInfo.measure, prevDieRes + 1);
					GetParent().RemoveChild(die);
					diceInst.Remove(dieInfo);
					if (currDice < 1250000)
					{
						SpawnDie(currDice/10000);
					} 
					else if (currDice == 1250000 + (startAmt * interval) - interval)
					{
						foreach (float key in dieResults[0].Keys)
						{
							for (int i = 0; i < 6; ++i)
							{

								GD.Print(key + " " + i + " " + dieResults[i].GetValueOrDefault(key));
							}
						}
					}
					currDice += interval;
					break;
				} else
				{
					++dieInfo.ticks[0];
				}

			}
		}
	}

	/// <summary>
	/// Spawns a die and gives it starting parameters.
	/// </summary>
	/// <param name="diceToSpawnIndex">Index of the dice to be spawned</param>
	public void SpawnDie(int diceToSpawnIndex)
	{
		Node3D diceToSpawn = (Node3D)dice[diceToSpawnIndex].Duplicate();
		RigidBody3D diceRigidBody = new RigidBody3D();
		diceRigidBody.AddChild(diceToSpawn);
		diceToSpawn.Position = Vector3.Zero;
		AddSibling(diceRigidBody);
		diceRigidBody.CollisionLayer = 0;
		diceRigidBody.CollisionMask = 1;
		diceRigidBody.ContinuousCd = true;

		CollisionShape3D diceShape = new CollisionShape3D();
		diceRigidBody.AddChild(diceShape);

		ConvexPolygonShape3D newShape = new ConvexPolygonShape3D();
		//((MeshInstance3D)NodeHelper.GetAllNodesOfType<MeshInstance3D>(diceToSpawn)[0])
		newShape.Points = NodeHelper.removeDuplicates<Vector3>(((MeshInstance3D)diceToSpawn).Mesh.GetFaces());
		diceShape.Set("shape", newShape);
		/*foreach (Vector3 v in NodeHelper.removeDuplicates<Vector3>(((MeshInstance3D)diceToSpawn).Mesh.GetFaces()))
		{
			GD.Print(v);
		}*/
		diceRigidBody.Position = new Vector3(0, 10, 0);
		diceRigidBody.Rotation = new Vector3(rand.Next(), rand.Next(), rand.Next());
		int maxStartLinVel = 100;
		int maxStartAngVel = 100;
		diceRigidBody.AngularVelocity = new Vector3(
			rand.Next(maxStartAngVel), 
			rand.Next(maxStartAngVel), 
			rand.Next(maxStartAngVel));
		diceRigidBody.LinearVelocity = new Vector3(
			rand.Next(maxStartLinVel) - (.5f * maxStartLinVel),
			rand.Next(maxStartLinVel) - (.5f * maxStartLinVel), 
			rand.Next(maxStartLinVel) - (.5f * maxStartLinVel));

		DieInfo dieInfo = new DieInfo();
		dieInfo.die = diceRigidBody;
		dieInfo.visualDie = (MeshInstance3D)diceToSpawn;
		dieInfo.type = (DieType)(diceToSpawnIndex / 25);
		dieInfo.ticks = new int[] {0, 0};
		if (diceToSpawnIndex % 25 < 20)
		{
			dieInfo.measure = ((diceToSpawnIndex + 1) % 25)/10.0f;
		} else
		{
			switch (diceToSpawnIndex % 25)
			{
				case 20:
					dieInfo.measure = 2.5f;
					break;
				case 21:
					dieInfo.measure = 3.0f;
					break;
				case 22:
					dieInfo.measure = 3.5f;
					break;
				case 23:
					dieInfo.measure = 4.0f;
					break;
				case 24:
					dieInfo.measure = 5.0f;
					break;
				default:
					dieInfo.measure = 0;
					break;
			}
		}
		diceInst.Add(dieInfo);
	}

	public void EndWait(Waitable.WaitEvent waitEvent)
	{
		switch (waitEvent)
		{
			case Waitable.WaitEvent.START_SPAWN:
				for (int i = 0; i < startAmt; ++i)
				{
					SpawnDie(currDice/10000);
					currDice += interval;
				}
				break;
			default: 
				break;
		}
	}
}
