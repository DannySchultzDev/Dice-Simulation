using Godot;
using System;
using System.Reflection;

public partial class CamControl : Camera3D
{
	// Called when the node enters the scene tree for the first time.
	public override void _Ready()
	{
	}

	// Called every frame. 'delta' is the elapsed time since the previous frame.
	public override void _Process(double delta)
	{
		float h = 0;
		float v = 0;
		float hsp = 3;
		float vsp = 10;
		if (Input.IsKeyPressed(Key.A))
		{
			--h;
		}
		if (Input.IsKeyPressed(Key.D))
		{
			++h;
		}
		if (Input.IsKeyPressed(Key.W))
		{
			--v;
		}
		if (Input.IsKeyPressed(Key.S))
		{
			++v;
		}
		Translate(new Vector3(h * (float)delta *  hsp, 0, v * (float)delta) * vsp);

		float h2 = 0;
		float sp2 = 3;
		if (Input.IsKeyPressed(Key.Right))
		{
			--h2;
		}
		if (Input.IsKeyPressed(Key.Left))
		{
			++h2;
		}
		Rotate(new Vector3(0, 1, 0), h2 * (float)delta * sp2);
	}
}
