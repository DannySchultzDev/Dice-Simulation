using Godot;
using System;

public interface Waitable
{
	public enum WaitEvent 
	{
		START_SPAWN,

		DESTROY_DIE
	}

	public void EndWait(WaitEvent waitEvent);
}
