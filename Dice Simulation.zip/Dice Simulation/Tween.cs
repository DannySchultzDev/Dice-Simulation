using Godot;
using System;
using System.Collections.Generic;
using static Waitable;

public partial class Tween : Node
{
	public static Tween tween;

	public enum TweenType
	{
		POSITION,
		ROTATION,
		SCALE,
		COLOR
	}
	private struct TweenEvent
	{
		public Object tweenObj;
		public TweenType tweenType;
		public Vector3 startVal;
		public Vector3 targetVal;
		public Object targetObj;
		public float startTime;
		public float timeRemaining;
	}

	private struct WaitEvent
	{
		public Waitable waitObj;
		public Waitable.WaitEvent waitEvent;
		public float timeRemaining;
	}

	private static List<TweenEvent> tweenEvents = new List<TweenEvent>();
	private static List<WaitEvent> waitEvents = new List<WaitEvent>();

	// Called when the node enters the scene tree for the first time.
	public override void _Ready()
	{
		tween = this;
	}

	// Called every frame. 'delta' is the elapsed time since the previous frame.
	public override void _Process(double delta)
	{
		for (int i = 0; i < tweenEvents.Count; ++i)
		{
			TweenEvent tweenEvent = tweenEvents[i];
			
			switch (tweenEvent.tweenType)
			{
				case TweenType.POSITION:
					if (tweenEvent.targetObj == null)
					{
						Vector3 newPosition = tweenEvent.targetVal - tweenEvent.startVal;
						newPosition *= 1 - (tweenEvent.timeRemaining / tweenEvent.startTime);
						newPosition += tweenEvent.startVal;
						((Node3D)tweenEvent.tweenObj).Position = newPosition;
					}
					break;
				case TweenType.ROTATION:
					if (tweenEvent.targetObj == null)
					{
						Vector3 newRotation = tweenEvent.targetVal - tweenEvent.startVal;
						newRotation *= 1 - (tweenEvent.timeRemaining / tweenEvent.startTime);
						newRotation += tweenEvent.startVal;
						((Node3D)tweenEvent.tweenObj).Rotation = newRotation;
					}
					break;
				case TweenType.SCALE:
					if (tweenEvent.targetObj == null)
					{
						Vector3 newScale = tweenEvent.targetVal - tweenEvent.startVal;
						newScale *= 1 - (tweenEvent.timeRemaining / tweenEvent.startTime);
						newScale += tweenEvent.startVal;
						((Node3D)tweenEvent.tweenObj).Scale = newScale;
					}
					break;
				case TweenType.COLOR:
					if (tweenEvent.targetObj == null)
					{
						Vector3 newColorVector = tweenEvent.targetVal - tweenEvent.startVal;
						newColorVector *= 1 - (tweenEvent.timeRemaining / tweenEvent.startTime);
						newColorVector += tweenEvent.startVal;
						Color newColor = new Color(newColorVector.X, newColorVector.Y, newColorVector.Z);
						((Material)tweenEvent.tweenObj).Set("albedo_color", newColor);
					}
					break;
			}
			
			if (tweenEvent.timeRemaining <= 0)
			{
				tweenEvents.RemoveAt(i);
				--i;
			}
			else
			{
				tweenEvent.timeRemaining = Mathf.Clamp(tweenEvent.timeRemaining - (float)delta, 0, float.MaxValue);
				tweenEvents[i] = tweenEvent;
			}
		}

		for (int i = 0; i < waitEvents.Count; ++i)
		{
			WaitEvent waitEvent = waitEvents[i];
			if (waitEvent.timeRemaining <= 0)
			{
				if (((Node)waitEvent.waitObj).IsInsideTree())
				{
					waitEvent.waitObj.EndWait(waitEvent.waitEvent);
				}
				waitEvents.RemoveAt(i);
				--i;
			} else
			{
				waitEvent.timeRemaining -= (float)delta;
				waitEvents[i] = waitEvent;
			}
		}
	}

	public static void WaitToExecute (Waitable waitObj, Waitable.WaitEvent waitEvent, float waitTime)
	{
		WaitEvent newWaitEvent = new WaitEvent();
		newWaitEvent.waitObj = waitObj;
		newWaitEvent.waitEvent = waitEvent;
		newWaitEvent.timeRemaining = waitTime;
		waitEvents.Add(newWaitEvent);
	}
	private static void TweenObject (Object tweenObj, TweenType tweenType,Vector3 startVal, Vector3 targetVal, Object targetObj, float tweenTime)
	{
		foreach (TweenEvent tweenEvent in tweenEvents)
		{
			if (tweenEvent.tweenObj == tweenObj && tweenEvent.tweenType == tweenType)
			{
				return;
			}
		}
		TweenEvent newTweenEvent = new TweenEvent();
		newTweenEvent.tweenObj = tweenObj;
		newTweenEvent.tweenType = tweenType;
		newTweenEvent.startVal = startVal;
		newTweenEvent.targetVal = targetVal;
		newTweenEvent.targetObj = targetObj;
		newTweenEvent.startTime = tweenTime;
		newTweenEvent.timeRemaining = tweenTime;
		tweenEvents.Add(newTweenEvent);
	}

	public static void TweenPosition (Node3D tweenObj, Vector3 targetVal, float tweenTime)
	{
		TweenObject(tweenObj, TweenType.POSITION,tweenObj.Position, targetVal, null, tweenTime);
	}

	public static void TweenRotation(Node3D tweenObj, Vector3 targetVal, float tweenTime)
	{
		TweenObject(tweenObj, TweenType.ROTATION, tweenObj.Rotation, targetVal, null, tweenTime);
	}

	public static void TweenScale(Node3D tweenObj, Vector3 targetVal, float tweenTime)
	{
		TweenObject(tweenObj, TweenType.SCALE, tweenObj.Scale, targetVal, null, tweenTime);
	}

	public static void TweenColor(Material tweenObj, Vector3 targetVal, float tweenTime)
	{
		Color startColor = (Color)tweenObj.Get("albedo_color");
		Vector3 startColorVector = new Vector3(startColor.R, startColor.G, startColor.B);
		TweenObject(tweenObj, TweenType.COLOR, startColorVector, targetVal, null, tweenTime);
	}

	public static void TweenColor(Material tweenObj, Color targetVal, float tweenTime)
	{
		Vector3 targetColorVector = new Vector3(targetVal.R, targetVal.G, targetVal.B);
		TweenColor(tweenObj, targetColorVector, tweenTime);
	}

	public static void StopWaitToExecute(Waitable waitObj, Waitable.WaitEvent waitEvent)
	{
		for (int i = 0; i < waitEvents.Count; ++i)
		{
			WaitEvent currwaitEvent = waitEvents[i];
			if (currwaitEvent.waitObj == waitObj && currwaitEvent.waitEvent == waitEvent)
			{
				waitEvents.RemoveAt(i);
				break;
			}
		}
	}
}
