using Godot;
using System;
using System.Collections.Generic;

public static partial class NodeHelper
{
	public static List<Node> GetAllNodesOfType<T>(Node rootNode)
	{
		List<Node> list = new List<Node>();
		foreach (Node node in rootNode.GetChildren())
		{
			if (node.GetType() == typeof(T))
			{
				list.Add(node);
			}
			list.AddRange(GetAllNodesOfType<T>(node));
		}
		return list;
	}

	public static bool listContainsNode (List<Node> nodes, Node node)
	{
		foreach (Node child in nodes)
		{
			if (child.Name == node.Name)
			{
				return true;
			}
		}
		return false;
	}

	public static T[] removeDuplicates<T>(T[] inputArray)
	{
		List<T> uniqueList = new List<T>();

		foreach (T t in inputArray)
		{
			if (!uniqueList.Contains(t))
			{
				uniqueList.Add(t);
			}
		}

		return uniqueList.ToArray();
	}

	public static Vector3 CalculateAverageVertexPosition(MeshInstance3D meshInstance)
	{
		// Ensure the mesh instance has a valid mesh
		if (meshInstance.Mesh == null)
		{
			GD.PrintErr("MeshInstance3D has no valid mesh.");
			return Vector3.Zero;
		}

		ArrayMesh mesh = (ArrayMesh)meshInstance.Mesh;

		Vector3 totalVertexPosition = Vector3.Zero;
		int totalVertices = 0;

		for (int i = 0; i < mesh.GetSurfaceCount(); i++)
		{
			Godot.Collections.Array vertices = mesh.SurfaceGetArrays(i);

			foreach (Vector3 vertex in (Vector3[])vertices[0])
			{
				totalVertexPosition += vertex;
				totalVertices++;
			}
		}

		if (totalVertices == 0)
		{
			GD.PrintErr("Mesh has no vertices.");
			return Vector3.Zero;
		}

		Vector3 averageVertexPosition = totalVertexPosition / totalVertices;
		return averageVertexPosition;
	}
}
